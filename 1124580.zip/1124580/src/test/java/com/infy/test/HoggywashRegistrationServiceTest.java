package com.infy.test;

import java.util.ArrayList;
//import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


import com.infy.exception.HoggywashRegistrationException;
import com.infy.model.Applicant;
import com.infy.service.HoggywashRegistrationService;
import com.infy.service.HoggywashRegistrationServiceImpl;

public class HoggywashRegistrationServiceTest {

	private HoggywashRegistrationService service = new HoggywashRegistrationServiceImpl();
	
	@Test
	public void registerApplicantValidTest() throws HoggywashRegistrationException {
		List<String> list = new ArrayList<>();
		list.add("Spell Book");
		list.add("Theory of Magic");
		list.add("Dark Magic");
		Applicant appObj = new Applicant("Loraine",list, 5.5);
		HoggywashRegistrationException except = Assertions.assertThrows(HoggywashRegistrationException.class,
	              () -> service.registerApplicant(appObj));
		Assertions.assertEquals("Validator.INVALID_APPLICANT_NAME",except.getMessage());
	}
	
	@Test
	public void registerApplicantInvalidCauldronSizeTest() {
		List<String> list = new ArrayList<>();
		list.add("Spell Book");
		list.add("Theory of Magic");
		list.add("Dark Magic");
		Applicant appObj = new Applicant("Loraine",list, 50.0);
		
		HoggywashRegistrationException except = Assertions.assertThrows(HoggywashRegistrationException.class,
              () -> service.registerApplicant(appObj));
		Assertions.assertEquals("Validator.INVALID_APPLICANT_NAME",except.getMessage());
	}

}
