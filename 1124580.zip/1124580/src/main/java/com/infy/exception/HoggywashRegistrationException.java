package com.infy.exception;

public class HoggywashRegistrationException extends Exception {

	private static final long serialVersionUID = 1L;

	public HoggywashRegistrationException() {
		super();
	}

	public HoggywashRegistrationException(String message) {
		super(message);
	}

}
