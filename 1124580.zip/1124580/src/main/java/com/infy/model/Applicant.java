package com.infy.model;

import java.util.List;

//Strictly adhere to the class diagram while implementing
public class Applicant {
	private String applicantId;
	private String applicantName;
	private List<String> booksList;
	private Double cauldronSize;
	public Applicant() {
		// This non-parameterized constructor is already implemented for you
		
	}
	public Applicant(String applicantName, List<String> booksList, Double cauldronSize) {
		super();
		this.applicantName = applicantName;
		this.booksList = booksList;
		this.cauldronSize = cauldronSize;
	}
	public String getApplicantId() {
		return applicantId;
	}
	public void setApplicantId(String applicantId) {
		this.applicantId = applicantId;
	}
	public String getApplicantName() {
		return applicantName;
	}
	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}
	public List<String> getBooksList() {
		return booksList;
	}
	public void setBooksList(List<String> booksList) {
		this.booksList = booksList;
	}
	public Double getCauldronSize() {
		return cauldronSize;
	}
	public void setCauldronSize(Double cauldronSize) {
		this.cauldronSize = cauldronSize;
	}
	
}
