package com.infy.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.logging.LogFactory;

import com.infy.dao.HoggywashRegistrationDAO;
import com.infy.dao.HoggywashRegistrationDAOImpl;
import com.infy.exception.HoggywashRegistrationException;
import com.infy.model.Applicant;
import com.infy.validator.HoggywashRegistrationValidator;

public class HoggywashRegistrationServiceImpl implements HoggywashRegistrationService {

	private HoggywashRegistrationValidator validator = new HoggywashRegistrationValidator();

	private HoggywashRegistrationDAO dao = new HoggywashRegistrationDAOImpl();

	@Override
	public String registerApplicant(Applicant applicant) throws HoggywashRegistrationException {
		validator.validate(applicant);
		return dao.registerApplicant(applicant);
	}

	@Override
	public List<Applicant> getApplicantList(Double cauldronSize) throws HoggywashRegistrationException {
		List<Applicant> l1 = dao.getApplicantList();
		List<Applicant> temp =  new ArrayList<>();
		try {
			temp = l1.stream()
					.filter(appObj->appObj.getCauldronSize()>cauldronSize)
					.collect(Collectors.toList());
			if(temp == null || temp.isEmpty()) {
				throw new HoggywashRegistrationException("Service.NO_APPLICANTS_FOUND");
			}
		}catch(HoggywashRegistrationException e) {
			if(e.getMessage().startsWith("Service")) {
				LogFactory.getLog(getClass()).error(e.getMessage(),e);
				throw e;
			}
		}
		return temp;
	}

}
