package com.infy.service;

import java.util.List;

import com.infy.exception.HoggywashRegistrationException;
import com.infy.model.Applicant;

public interface HoggywashRegistrationService {
	String registerApplicant(Applicant applicant) throws HoggywashRegistrationException;
	List<Applicant> getApplicantList(Double cauldronSize) throws HoggywashRegistrationException;
}
