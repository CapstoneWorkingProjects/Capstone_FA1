package com.infy.validator;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.LogFactory;

import com.infy.exception.HoggywashRegistrationException;
import com.infy.model.Applicant;

public class HoggywashRegistrationValidator {
	public void validate(Applicant applicant) throws HoggywashRegistrationException {
//		Uncomment the below code once the Model class is implemented
		
		String exceptionMessage = null;
		if (Boolean.FALSE.equals(isValidCauldronSize(applicant.getCauldronSize()))) {
			exceptionMessage = "Validator.INVALID_CAULDRON_SIZE";
		}
		if (Boolean.FALSE.equals(isValidApplicantName(applicant.getApplicantName()))) {
			exceptionMessage = "Validator.INVALID_APPLICANT_NAME";
		}
		if (Boolean.FALSE.equals(isValidBooksList(applicant.getBooksList()))) {
			exceptionMessage = "Validator.INVALID_BOOKS_LIST";
		}
		if (exceptionMessage != null) {
			HoggywashRegistrationException exception = new HoggywashRegistrationException(exceptionMessage);
			LogFactory.getLog(getClass()).error(exception.getMessage(), exception);
			throw exception;
		}
	}

//	Modify the return statement based on the requirements provided
	public Boolean isValidCauldronSize(Double cauldronSize) {
		if(cauldronSize !=null && cauldronSize>1.0 && cauldronSize<10.0) {
			return true;
		}else {
			return false;
		}
	}

//	Modify the return statement based on the requirements provided
	public Boolean isValidApplicantName(String applicantName) {
		String regex = "([A-Za-z] {3,}+)";
		if(applicantName != null && !applicantName.isEmpty() && !applicantName.isBlank() && applicantName.matches(regex)) {
			return true;
		}else {
			return false;
		}
	}

//	Modify the return statement based on the requirements provided
	public Boolean isValidBooksList(List<String> booksList) {
		List<String> list = new ArrayList<>();
		list.add("Spell Book");
		list.add("Theory of Magic");
		list.add("Dark Magic");
		if(booksList!=null && !booksList.isEmpty() && (booksList.containsAll(list))) {
				return true;
		}else {
			return false;
		}
		
	}
}
