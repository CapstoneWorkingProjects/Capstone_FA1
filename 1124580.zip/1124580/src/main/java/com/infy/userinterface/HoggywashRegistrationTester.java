package com.infy.userinterface;

import java.util.List;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.infy.exception.HoggywashRegistrationException;
import com.infy.model.Applicant;
import com.infy.service.HoggywashRegistrationService;
import com.infy.service.HoggywashRegistrationServiceImpl;

public class HoggywashRegistrationTester {

	private static HoggywashRegistrationService service;
	private static PropertiesConfiguration propertiesConfiguration;

	private static final Log LOG = LogFactory.getLog(HoggywashRegistrationTester.class);

	public static void main(String[] args) throws ConfigurationException {
		service = new HoggywashRegistrationServiceImpl();
		propertiesConfiguration = new Configurations().properties("configuration.properties");
		registerApplicant();
		getApplicantList();
	}
	
//	Uncomment the below code once the Model class is implemented

	public static void registerApplicant() {
		LOG.info(propertiesConfiguration.getProperty("HoggywashRegistrationTester.REGISTER_APPLICANT"));
		try {
			List<String> booksList = List.of("Spell Book", "Theory of Magic", "Dark Magic");
			Applicant applicant = new Applicant("Happy", booksList, 5.5d);
			String applicantName = service.registerApplicant(applicant);
			LOG.info(propertiesConfiguration.getProperty("HoggywashRegistrationTester.REGISTER_SUCCESS") + " "
					+ applicantName + "!");
		} catch (HoggywashRegistrationException exception) {
			String errorMessage = (String) propertiesConfiguration.getProperty(exception.getMessage());
			if (errorMessage == null) {
				errorMessage = (String) propertiesConfiguration
						.getProperty("HoggywashRegistrationTester.GENERAL_EXCEPTION");
			}
			LOG.info("ERROR: " + errorMessage);
		}
	}

	public static void getApplicantList() {
		try {
			Double cauldronSize = 14d;
			LOG.info((String)propertiesConfiguration.getProperty("HoggywashRegistrationTester.GET_APPLICANT_LIST") + " " + cauldronSize);
			List<Applicant> applicantList = service.getApplicantList(cauldronSize);
			LOG.info("=".repeat(75));
			String format = "%s %-15s %s %-30s %s %-20s %s";
			String bar = "|";
			LOG.info(String.format(format, bar, "Applicant ID", bar, "Applicant Name", bar, "Cauldron Size", bar));
			LOG.info("=".repeat(75));
			for (Applicant applicant : applicantList) {
				LOG.info(String.format(format, bar, applicant.getApplicantId(), bar, applicant.getApplicantName(), bar,
						applicant.getCauldronSize(), bar));
			}
			LOG.info("=".repeat(75));
		} catch (HoggywashRegistrationException exception) {
			String errorMessage = (String) propertiesConfiguration.getProperty(exception.getMessage());
			if (errorMessage == null) {
				errorMessage = (String) propertiesConfiguration
						.getProperty("HoggywashRegistrationTester.GENERAL_EXCEPTION");
			}
			LOG.info("ERROR: " + errorMessage);
		}
	}
}
