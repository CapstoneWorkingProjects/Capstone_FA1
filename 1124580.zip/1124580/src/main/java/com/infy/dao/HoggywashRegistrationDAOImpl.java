package com.infy.dao;

import java.util.ArrayList;
import java.util.List;

import com.infy.model.Applicant;

public class HoggywashRegistrationDAOImpl implements HoggywashRegistrationDAO {

	private List<Applicant> applicantList;

	public HoggywashRegistrationDAOImpl() {
		applicantList = new ArrayList<>();

//		Uncomment the below code once the Model class is implemented

		List<String> booksList = List.of("Spell Book", "Theory of Magic", "Dark Magic");
		Applicant applicant1 = new Applicant("Ronny", booksList, 2.5d);
		Applicant applicant2 = new Applicant("Rose", booksList, 4d);
		Applicant applicant3 = new Applicant("Kally", booksList, 6.8d);
		Applicant applicant4 = new Applicant("Joseph", booksList, 1.5d);
		Applicant applicant5 = new Applicant("Piper", booksList, 5.9d);
		Applicant applicant6 = new Applicant("Albie", booksList, 3.7d);
		Applicant applicant7 = new Applicant("Lucas", booksList, 9.3d);
		Applicant applicant8 = new Applicant("Maddie", booksList, 8.1d);
		Applicant applicant9 = new Applicant("Karl", booksList, 3d);
		Applicant applicant10 = new Applicant("Benji", booksList, 7.4d);

		applicantList.add(applicant1);
		applicantList.add(applicant2);
		applicantList.add(applicant3);
		applicantList.add(applicant4);
		applicantList.add(applicant5);
		applicantList.add(applicant6);
		applicantList.add(applicant7);
		applicantList.add(applicant8);
		applicantList.add(applicant9);
		applicantList.add(applicant10);
//		
		for (Applicant applicant : applicantList) {
			applicant.setApplicantId(applicant.getApplicantName().substring(0, 2).toUpperCase() + "-"
					+ Math.round(applicant.getCauldronSize()));
		}
	}

	@Override
	public String registerApplicant(Applicant applicant) {

//		Uncomment the below code once the Model class is implemented and comment the return null statement

		return applicant.getApplicantName();
//		return null;
	}

	@Override
	public List<Applicant> getApplicantList() {
		return applicantList;
	}

}
