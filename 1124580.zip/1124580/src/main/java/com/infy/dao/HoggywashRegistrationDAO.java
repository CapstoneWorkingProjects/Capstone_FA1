package com.infy.dao;

import java.util.List;

import com.infy.model.Applicant;

public interface HoggywashRegistrationDAO {
	String registerApplicant(Applicant applicant);
	List<Applicant> getApplicantList();
}
