package com.issuetracker.validator;

import java.time.LocalDate;

import org.apache.commons.logging.Log;
//import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.issuetracker.exception.IssueTrackerException;
import com.issuetracker.model.Issue;
import com.issuetracker.model.IssueStatus;

// Do Not Change Any Signature
public class Validator
{	
    public void validate(Issue issue) throws IssueTrackerException
    {	Log logger = LogFactory.getLog(Validator.class);
    	try {
    	    if(issue.getIssueId() == null ||!isValidIssueId(issue.getIssueId()))
    		throw new IssueTrackerException("Validator.INVALID_ISSUE_ID");
    	    if(!isValidIssueDescription(issue.getIssueDescription()))
    		throw new IssueTrackerException("Validator.INVALID_ISSUE_DESCRIPTION");
    	    if(!isValidReportedOn(issue.getReportedOn()))
    		throw new IssueTrackerException("Validator.INVALID_REPORTED_DATE");
    	    if(!isValidStatus(issue.getStatus()))
    		throw new IssueTrackerException("Validator.INVALID_STATUS");
    	    
    	    
    	}catch(IssueTrackerException e) {
    	    logger.error(e.getMessage(),e);
    	    throw e;
    	}
    
	// Your Code Goes Here
    }

    public Boolean isValidIssueId(String issueId)
    {
	// Your Code Goes Here
	String regex = "(MTI-I)[-]([1-9][0-9][0-9]|[0-9][1-9][0-9]|[0-9][0-9][1-9])"
			+ "[-](([L][S])|([M][S])|([H][S]))";
	if(issueId!=null && !issueId.isEmpty() && issueId.matches(regex))
	    return true;
	else
	    return false;
    }

    public Boolean isValidIssueDescription(String issueDescription)
    {
	// Your Code Goes Here
	String regex = "([A-Za-z]+([\\s][A-Za-z]+)*)";
	if(issueDescription!=null && !issueDescription.isBlank() && !issueDescription.isEmpty()
		&& issueDescription.matches(regex) && issueDescription.length()>=1 && issueDescription.length()<=50) {
	    return true;
	}
	else {
	    return false;
    
	}
    }
    public Boolean isValidReportedOn(LocalDate reportedOn)
    {
	// Your Code Goes Here
	LocalDate today = LocalDate.now();
	if(reportedOn!=null && (reportedOn.isBefore(today) || reportedOn.isEqual(today)))
	    return true;
	else
	    return false;
    }

    public Boolean isValidStatus(IssueStatus status)
    {
	// Your Code Goes Here
	if(status!=null &&(status == IssueStatus.OPEN || status == IssueStatus.IN_PROGRESS))
	    return true;
	else
	    return false;
    }
}