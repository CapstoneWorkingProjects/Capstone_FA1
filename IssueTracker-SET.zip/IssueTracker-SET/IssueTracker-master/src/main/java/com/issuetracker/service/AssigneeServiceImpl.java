package com.issuetracker.service;

import java.util.List;
import java.util.stream.Collectors;

import com.issuetracker.dao.AssigneeDAO;
import com.issuetracker.model.Assignee;
import com.issuetracker.model.Unit;

// Do Not Change Any Signature
public class AssigneeServiceImpl implements AssigneeService
{
    private AssigneeDAO assigneeDAO;

    @Override
    public List<Assignee> fetchAssignee(Unit unit)
    {
	// Your Code Goes Here
	List<Assignee> assigneeList = assigneeDAO.fetchAssignees(unit);
	return assigneeList.stream()
		.filter(assign -> assign.getNumberOfIssuesActive()<3)
		.collect(Collectors.toList());
    }

    @Override
    public void updateActiveIssueCount(String assigneeEmail,
				       Character operation)
    {
	// Your Code Goes Here
	Assignee assgnObj = assigneeDAO.getAssigneeByEmail(assigneeEmail);
	if(operation == 'I') {
	    assgnObj.setNumberOfIssuesActive(assgnObj.getNumberOfIssuesActive()+1);
	}else if(operation == 'D') {
	    assgnObj.setNumberOfIssuesActive(assgnObj.getNumberOfIssuesActive()-1);
	}
    }
}