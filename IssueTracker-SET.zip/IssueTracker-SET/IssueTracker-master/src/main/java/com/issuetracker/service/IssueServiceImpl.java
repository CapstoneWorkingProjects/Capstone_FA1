package com.issuetracker.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.issuetracker.dao.IssueDAO;
import com.issuetracker.dao.IssueDAOImpl;
import com.issuetracker.exception.IssueTrackerException;
import com.issuetracker.model.Assignee;
import com.issuetracker.model.Issue;
import com.issuetracker.model.IssueReport;
import com.issuetracker.model.IssueStatus;
import com.issuetracker.validator.Validator;

// Do Not Change Any Signature
public class IssueServiceImpl implements IssueService
{
    private AssigneeService assigneeService = new AssigneeServiceImpl();
    private IssueDAO issueDAO = new IssueDAOImpl();
    private Validator validator = new Validator();

    @Override
    public String reportAnIssue(Issue issue) throws IssueTrackerException
    {
	// Your Code Goes Here
	Log logger = LogFactory.getLog(IssueServiceImpl.class);
	validator.validate(issue);
	try {
	    List<Assignee> availabelAssigneeList = assigneeService.fetchAssignee(issue.getIssueUnit());
	    if(availabelAssigneeList!= null && !availabelAssigneeList.isEmpty()) {
		Assignee firstAssignee = availabelAssigneeList.get(0);
		issue.setAssigneeEmail(firstAssignee.getAssigneeEmail());
		assigneeService.updateActiveIssueCount(firstAssignee.getAssigneeEmail(), 'I');
	    }
	    String issueId = issueDAO.reportAnIssue(issue);
	    if(issueId == null) {
		throw new IssueTrackerException("IssueService.DUPLICATE_ISSUE_ID");
	    }
	    return issueId;
	    
	}catch(IssueTrackerException e) {
	    logger.error(e.getMessage(),e);
	    throw e;
	}
	
    }

    @Override
    public Boolean updateStatus(String issueId,
				IssueStatus status) throws IssueTrackerException
    {
	// Your Code Goes Here
	Log logger = LogFactory.getLog(IssueServiceImpl.class);
	Issue obj = issueDAO.getIssueById(issueId);
	try {
        	if(obj == null) {
        	    throw new IssueTrackerException("IssueService.ISSUE_NOT_FOUND");
        	}
        	if(obj.getStatus() == status) {
        	    throw new IssueTrackerException("IssueService.NO_STATUS_CHANGE");
        	}
        	if(obj.getStatus()!=IssueStatus.OPEN && status==IssueStatus.RECALLED) {
        	    throw new IssueTrackerException("IssueService.INCOMPATIBLE_STATUS");
        	}
	}catch(IssueTrackerException e) {
	    logger.error(e.getMessage(),e);
	    throw e;
	}
	issueDAO.updateStatus(obj, status);
	if(obj.getStatus()!=IssueStatus.OPEN || obj.getStatus()!=IssueStatus.IN_PROGRESS) {
	    assigneeService.updateActiveIssueCount(obj.getAssigneeEmail(), 'D');
	}
	return true;
    }

    @Override
    public List<IssueReport> showIssues(Map<Character, Object> filterCriteria) throws IssueTrackerException
    {
	// Your Code Goes Here
	Log logger = LogFactory.getLog(IssueServiceImpl.class);
	List<Issue> issueObjects = issueDAO.getIssueList();
	List<Issue> list;	
	try {
	    if(filterCriteria.containsKey('A')) {
		list = issueObjects.stream()
			.filter(issueObj-> issueObj.getAssigneeEmail()==filterCriteria.get('A'))
			.collect(Collectors.toList());
	    }else {
		list = issueObjects.stream()
			.filter(issueObj-> issueObj.getAssigneeEmail()==filterCriteria.get('S'))
			.collect(Collectors.toList());
	    }
	    if(list == null || list.isEmpty()) {
		throw new IssueTrackerException("IssueService.NO_ISSUES_FOUND");
	    }
	    
	}catch(IssueTrackerException e) {
	    logger.error(e.getMessage(),e);
	    throw e;
	
	}
	List<IssueReport> reportlist = new ArrayList<IssueReport>();
	for(Issue obj : list) {
	    reportlist.add(new IssueReport(obj.getIssueId(), obj.getIssueDescription(), obj.getAssigneeEmail(), obj.getStatus())); 
	}
	return reportlist;
    }

    @Override
    public List<Issue> deleteIssues() throws IssueTrackerException
    {
	Log logger = LogFactory.getLog(IssueServiceImpl.class);
	List<Issue> issueObjects = issueDAO.getIssueList();
	List<Issue> newList = new ArrayList<Issue>();
	
	for(Issue obj : issueObjects) {
	    if((obj.getStatus() == IssueStatus.CLOSED || obj.getStatus() == IssueStatus.RESOLVED) 
		    && obj.getReportedOn().isBefore(LocalDate.now().minusDays(14))) {
		newList.add(obj);
	    }
	}
	try {
	    if(newList == null || newList.isEmpty()) {
		throw new IssueTrackerException("IssueService.NO_ISSUES_DELETED");
	    }
	    
	}catch(IssueTrackerException e) {
	    logger.error(e.getMessage(),e);
	    throw e;
	}
	for(Issue obj : newList) {
	    issueDAO.getIssueList().remove(obj);
	}

	return newList;
    }
}