package com.infy.test;


import java.util.Arrays;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.infy.model.ServiceRequest;
import com.infy.service.MobileService;
import com.infy.service.MobileServiceImpl;


public class MobileServiceTest {
	private MobileService mobileService = new MobileServiceImpl();
    @Test
	public void registerRequestInvalidBrandTest() {
		ServiceRequest service = new ServiceRequest("abc", Arrays.asList("Battery"), 9876543210L,"Chap",3214567890123456L);
		

	Exception exception = Assertions.assertThrows(Exception.class,
						      () -> mobileService.registerRequest(service));
	Assertions.assertEquals("Validator.INVALID_BRAND",
				exception.getMessage());

	}
    @Test
	public void registerRequestInvalidContactNumberTest() {
		//your code goes here
		ServiceRequest service = new ServiceRequest("Twoplusone", Arrays.asList("Battery"), 98765L,"Chap",3214567890123456L);
		

		Exception exception = Assertions.assertThrows(Exception.class,
							      () -> mobileService.registerRequest(service));
		Assertions.assertEquals("Validator.INVALID_CONTACT_NUMBER",
					exception.getMessage());
	}
    @Test
	public void registerRequestInvalidIssuesTest() {
		//your code goes here
		ServiceRequest service = new ServiceRequest("Twoplusone", Arrays.asList("Broken Screen"), 9876543210L,"Chap",3214567890123456L);
		

		Exception exception = Assertions.assertThrows(Exception.class,
							      () -> mobileService.registerRequest(service));
		Assertions.assertEquals("Service.INVALID_ISSUES",
					exception.getMessage());
	}

}
